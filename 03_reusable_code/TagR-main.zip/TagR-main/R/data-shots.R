#' Anonymized TeamTV shot dataset
#'
#' A small anonymized dataset exported from the TeamTV application, containing
#' tagged korfball shots and related metadata. Intended for examples and tests.
#'
#' @format A data frame with 1196 rows and 37 variables.
#' @source Generated from a TeamTV export and anonymized.
"shots"



