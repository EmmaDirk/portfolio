# TagR 0.2.1

# TagR 0.2.0

# TagR 0.1.0

* Initial submission.
